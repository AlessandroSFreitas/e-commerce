$(function() {
  $('.datepicker').datepicker();
});
